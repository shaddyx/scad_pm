
from setuptools import setup

setup(
    name='scad_pm',
    version='0.4',
    scripts=['src/scad_pm.py']
)